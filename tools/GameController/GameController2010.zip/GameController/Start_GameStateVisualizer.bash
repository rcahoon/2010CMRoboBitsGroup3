#!/bin/bash

set -eu

echo Starting GameStateVisualizer

java -jar GameStateVisualizer.jar -spl
